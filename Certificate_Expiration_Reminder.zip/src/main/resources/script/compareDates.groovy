import com.sap.it.api.mapping.*;
import java.text.SimpleDateFormat
import java.util.Date

def String dateDifferenceInDays(String checkDate){
    /* returns time difference in days of given date with current date */ 
    def dateFormat = new SimpleDateFormat("yyyy-MM-dd")    
    def currentDate = new Date()
    def date1 = dateFormat.parse(checkDate)
    def date2 = dateFormat.parse(dateFormat.format(currentDate))
    def timeDifference = date1.time - date2.time
    def daysDifference = timeDifference / (1000 * 60 * 60 * 24)
    
    return daysDifference
	
}
